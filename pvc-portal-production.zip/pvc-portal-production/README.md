# PVC Ration Card Portal — Production Deployment Guide

## Folder structure

```
pvc-portal-production/
├── server/          # Node.js API server (pre-built)
├── public/          # React frontend static files (pre-built)
├── package.json
├── .env.example     # Copy to .env and fill in values
└── README.md
```

## Prerequisites

- Node.js 20 or higher
- PostgreSQL database (you can use Hostinger's managed MySQL/PostgreSQL, or an external provider like Neon, Supabase, or Aiven)

## Step-by-step setup on Hostinger

### 1. Upload files

Upload the entire `pvc-portal-production/` folder contents to your Hostinger Node.js hosting root (usually `public_html/` or the folder your Hostinger panel points to).

### 2. Create your PostgreSQL database

In your Hostinger control panel (or an external provider), create a PostgreSQL database and note the connection string:
```
postgresql://USER:PASSWORD@HOST:PORT/DATABASE
```

### 3. Set environment variables

In Hostinger's Node.js app panel, add these environment variables:

| Variable        | Value                                      |
|-----------------|--------------------------------------------|
| `DATABASE_URL`  | Your PostgreSQL connection string          |
| `PORT`          | `3000` (or whatever Hostinger assigns)     |
| `SESSION_SECRET`| A random string of 32+ characters         |

Alternatively, create a `.env` file in the root (copy from `.env.example`) — but prefer the Hostinger panel for secrets.

### 4. Run database migrations

SSH into your Hostinger server and run:

```bash
# One-time setup: push the database schema
npx drizzle-kit push --config=drizzle.config.ts
```

> **Note:** If you do not have drizzle-kit available on the server, run the migration locally against your production DATABASE_URL before uploading, or use the SQL below to create the tables manually.

#### Manual SQL (if you cannot run drizzle-kit on the server)

```sql
CREATE TABLE IF NOT EXISTS orders (
  id           SERIAL PRIMARY KEY,
  order_number TEXT    NOT NULL UNIQUE,
  customer_name     TEXT NOT NULL,
  customer_phone    TEXT NOT NULL,
  ration_card_number TEXT NOT NULL,
  delivery_name     TEXT,
  address           TEXT NOT NULL,
  post_office       TEXT,
  state             TEXT NOT NULL,
  district          TEXT NOT NULL,
  pincode           TEXT NOT NULL,
  card_type         TEXT NOT NULL,
  quantity          INTEGER NOT NULL DEFAULT 1,
  amount            NUMERIC(10,2) NOT NULL,
  family_cards      JSONB NOT NULL DEFAULT '[]',
  payment_status    TEXT NOT NULL DEFAULT 'pending',
  payment_method    TEXT,
  created_at        TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMP NOT NULL DEFAULT NOW()
);
```

### 5. Start the server

In Hostinger's Node.js panel, set the **startup file / entry point** to:
```
server/index.mjs
```

Or if Hostinger uses `npm start`, that is already configured in `package.json`.

### 6. Point your domain

In Hostinger's domain/DNS settings, point your domain to the Node.js app. Hostinger handles HTTPS automatically with Let's Encrypt.

## Verify it is working

Open your domain in a browser. You should see the PVC Ration Card Portal home page.
Test the API: `https://yourdomain.com/api/healthz` — should return `{"status":"ok"}`.

## Troubleshooting

| Symptom | Fix |
|---|---|
| White screen / 404 on refresh | Ensure the SPA fallback is active (it is built-in — no extra config needed) |
| `DATABASE_URL not set` error | Set the env var in Hostinger's panel and restart the app |
| `PORT` conflict | Change `PORT` to `8080` or whatever Hostinger assigns |
| DB connection refused | Check your PostgreSQL host, user, password, and that the DB allows remote connections |
